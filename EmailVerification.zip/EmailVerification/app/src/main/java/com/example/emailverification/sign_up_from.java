package com.example.emailverification;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class sign_up_from extends AppCompatActivity {

    EditText email_Et, pass_Et, cpass_Et,name_Et;
    Button btn_Reg;
    ProgressBar Prg;

    private FirebaseAuth firebaseAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("Signup Form");

        name_Et = (EditText)findViewById(R.id.name_et);
        email_Et = (EditText) findViewById(R.id.email_et);
        pass_Et = (EditText) findViewById(R.id.pass_et);
        cpass_Et = (EditText) findViewById(R.id.cpass_et);
        btn_Reg = (Button) findViewById(R.id.reg_btn);
        Prg = (ProgressBar) findViewById(R.id.prg);




        firebaseAuth = FirebaseAuth.getInstance();

        btn_Reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String name = name_Et.getText().toString().trim();
                String email = email_Et.getText().toString().trim();
                String password = pass_Et.getText().toString().trim();
                String confrimpassword = cpass_Et.getText().toString().trim();


                if (TextUtils.isEmpty(name)) {
                    Toast.makeText(sign_up_from.this, "Please enter user name", Toast.LENGTH_LONG).show();
                    return;
                }

                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(sign_up_from.this, "Please enter e-mail address", Toast.LENGTH_LONG).show();
                    return;
                }

                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(sign_up_from.this, "Please enter password", Toast.LENGTH_LONG).show();
                    return;
                }

                if (TextUtils.isEmpty(confrimpassword)) {
                    Toast.makeText(sign_up_from.this, "Please confirm password", Toast.LENGTH_LONG).show();
                    return;
                }

                if (password.length() < 7) {
                    Toast.makeText(sign_up_from.this, "Password is too short", Toast.LENGTH_LONG).show();

                }

                Prg.setVisibility(View.VISIBLE);

                if (password.equals(confrimpassword)){

                    firebaseAuth.createUserWithEmailAndPassword(email, password)
                            .addOnCompleteListener(sign_up_from.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    Prg.setVisibility(View.GONE);
                                    if (task.isSuccessful()) {
                                        startActivity(new Intent(getApplicationContext(),registered_user.class));
                                        Toast.makeText(sign_up_from.this,"Authentication completed",Toast.LENGTH_LONG).show();

                                    } else {

                                        Toast.makeText(sign_up_from.this,"Authentication failed",Toast.LENGTH_LONG).show();

                                    }

                                                                    }
                            });

                }


            }

        });


    }

}