package com.example.emailverification;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class log_in_form extends AppCompatActivity {

    EditText txtEmail,txtPass;
    Button btnLog;


    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in_form);
        getSupportActionBar().setTitle("Login Form");

        txtEmail = (EditText)findViewById(R.id.txtemail);
        txtPass = (EditText)findViewById(R.id.txtpass);
        btnLog = (Button)findViewById(R.id.btnlog);


        firebaseAuth = FirebaseAuth.getInstance();

        btnLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = txtEmail.getText().toString().trim();
                String password = txtPass.getText().toString().trim();

                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(log_in_form.this, "Please enter e-mail eddress", Toast.LENGTH_LONG).show();
                    return;
                }

                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(log_in_form.this, "Please enter password", Toast.LENGTH_LONG).show();
                    return;
                }
                if (password.length() < 7) {
                    Toast.makeText(log_in_form.this, "Password too short", Toast.LENGTH_LONG).show();

                }



                firebaseAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(log_in_form.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {

                                    startActivity(new Intent(getApplicationContext(),registered_user.class));
                                    Toast.makeText(log_in_form.this,"Log in successfully",Toast.LENGTH_LONG).show();

                                }
                                else
                                    {

                                        Toast.makeText(log_in_form.this,"Log in failed or Unavailable user",Toast.LENGTH_LONG).show();
                                    }



                            }
                        });



            }




        });






    }

    public void btn_sign_up(View view) {

        startActivity(new Intent(getApplicationContext(),sign_up_from.class));
    }

}